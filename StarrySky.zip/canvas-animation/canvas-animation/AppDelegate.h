//
//  AppDelegate.h
//  canvas-animation
//
//  Created by 快游 on 2019/5/30.
//  Copyright © 2019 zhengcong. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

