//
//  main.m
//  canvas-animation
//
//  Created by 快游 on 2019/5/30.
//  Copyright © 2019 zhengcong. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
